import { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [tab, setTab] = useState('landlord');
  const [properties, setProperties] = useState([]);
  const [payments, setPayments] = useState([]);
  const [reviews, setReviews] = useState([]);

  const fetchAll = async () => {
    const [prop, pay, rev] = await Promise.all([
      axios.get('https://your-backend-url.onrender.com/api/properties'),
      axios.get('https://your-backend-url.onrender.com/api/payments'),
      axios.get('https://your-backend-url.onrender.com/api/reviews')
    ]);
    setProperties(prop.data);
    setPayments(pay.data);
    setReviews(rev.data);
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const submitForm = async (e, url) => {
    e.preventDefault();
    const formData = Object.fromEntries(new FormData(e.target).entries());
    await axios.post(`https://your-backend-url.onrender.com${url}`, formData);
    e.target.reset();
    fetchAll();
  };

  return (
    <main className="max-w-3xl mx-auto p-4 font-sans">
      <h1 className="text-3xl font-bold mb-6">Plataforma de Renta Automática</h1>

      <div className="flex gap-4 mb-4">
        <button onClick={() => setTab('landlord')} className={`px-4 py-2 rounded ${tab === 'landlord' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}>Arrendador</button>
        <button onClick={() => setTab('tenant')} className={`px-4 py-2 rounded ${tab === 'tenant' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}>Inquilino</button>
      </div>

      {tab === 'landlord' && (
        <section>
          <form onSubmit={(e) => submitForm(e, '/api/properties')} className="mb-4 grid gap-2">
            <input name="name" placeholder="Nombre de propiedad" className="border p-2 rounded" required />
            <input name="price" type="number" placeholder="Precio mensual" className="border p-2 rounded" required />
            <button className="bg-green-500 text-white px-4 py-2 rounded">Guardar propiedad</button>
          </form>

          <ul className="list-disc pl-5">
            {properties.map((p, i) => (
              <li key={i}>{p.name} - ${p.price}</li>
            ))}
          </ul>
        </section>
      )}

      {tab === 'tenant' && (
        <section>
          <form onSubmit={(e) => submitForm(e, '/api/payments')} className="mb-4 grid gap-2">
            <input name="property" placeholder="Propiedad" className="border p-2 rounded" required />
            <input name="amount" type="number" placeholder="Monto" className="border p-2 rounded" required />
            <button className="bg-green-500 text-white px-4 py-2 rounded">Pagar</button>
          </form>

          <ul className="list-disc pl-5">
            {payments.map((p, i) => (
              <li key={i}>{p.property} - ${p.amount} - {p.date}</li>
            ))}
          </ul>
        </section>
      )}

      <section className="mt-8">
        <form onSubmit={(e) => submitForm(e, '/api/reviews')} className="grid gap-2 mb-4">
          <input name="for" placeholder="Para (nombre de usuario)" className="border p-2 rounded" required />
          <input name="text" placeholder="Tu reseña" className="border p-2 rounded" required />
          <button className="bg-blue-500 text-white px-4 py-2 rounded">Enviar Reseña</button>
        </form>

        <ul className="list-disc pl-5">
          {reviews.map((r, i) => (
            <li key={i}><strong>{r.for}</strong>: {r.text}</li>
          ))}
        </ul>
      </section>
    </main>
  );
}

export default App;
